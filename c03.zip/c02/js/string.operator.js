// criando as variáveis e armazenando valores
var greeting = "Muito Prazer ";

var name = "João Victor";

var mensagemBoasVindas = greeting + name + '!';

var el = document.getElementById('greeting');

el.textContent = mensagemBoasVindas;
