// criando um arrau construtor

var colors = new Array(
                        'Branco',
                        'Preto',
                        'Personalidado'
                    );

var el = document.getElementById('cor');
el.textContent = colors[0];