// criando o array literal com valores

var colors;
colors = [
    'branco',
    'preto',
    'personalizado',
    'azul'
];

var el = document.getElementById('cor');
el.textContent = colors[0];